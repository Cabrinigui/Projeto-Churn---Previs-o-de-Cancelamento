import streamlit as st
import pandas as pd
import numpy as np
import joblib

# Carregando modelos, scaler e colunas esperadas
log_model = joblib.load('modelo_logistico.pkl')
scaler = joblib.load('scaler.pkl')
colunas_modelo = joblib.load('colunas_modelo.pkl')

# Título do app
st.title('🔍 Previsão de Churn de Cliente - Telco')
st.markdown("Informe os dados do cliente para prever se ele está propenso a churn (cancelamento).")

# Dicionário com os valores esperados para entradas categóricas
inputs = {}

# Inputs numéricos
inputs['tenure'] = st.number_input('Meses como cliente (tenure)', min_value=0, max_value=100, value=12)
inputs['MonthlyCharges'] = st.number_input('Custo mensal (MonthlyCharges)', min_value=0.0, value=70.0)
inputs['TotalCharges'] = st.number_input('Custo total (TotalCharges)', min_value=0.0, value=800.0)

# Inputs categóricos (binarizados automaticamente via get_dummies)
inputs['gender'] = st.selectbox('Gênero', ['Female', 'Male'])
inputs['SeniorCitizen'] = st.selectbox('Idoso?', ['No', 'Yes'])
inputs['Partner'] = st.selectbox('Tem parceiro?', ['No', 'Yes'])
inputs['Dependents'] = st.selectbox('Tem dependentes?', ['No', 'Yes'])
inputs['PhoneService'] = st.selectbox('Possui telefone?', ['No', 'Yes'])
inputs['MultipleLines'] = st.selectbox('Linhass múltiplas', ['No', 'Yes', 'No phone service'])
inputs['InternetService'] = st.selectbox('Tipo de internet', ['DSL', 'Fiber optic', 'No'])
inputs['OnlineSecurity'] = st.selectbox('Segurança online', ['No', 'Yes', 'No internet service'])
inputs['OnlineBackup'] = st.selectbox('Backup online', ['No', 'Yes', 'No internet service'])
inputs['DeviceProtection'] = st.selectbox('Proteção de dispositivos', ['No', 'Yes', 'No internet service'])
inputs['TechSupport'] = st.selectbox('Suporte técnico', ['No', 'Yes', 'No internet service'])
inputs['StreamingTV'] = st.selectbox('Streaming TV', ['No', 'Yes', 'No internet service'])
inputs['StreamingMovies'] = st.selectbox('Streaming Filmes', ['No', 'Yes', 'No internet service'])
inputs['Contract'] = st.selectbox('Tipo de contrato', ['Month-to-month', 'One year', 'Two year'])
inputs['PaperlessBilling'] = st.selectbox('Fatura digital?', ['No', 'Yes'])
inputs['PaymentMethod'] = st.selectbox('Forma de pagamento', [
    'Electronic check', 'Mailed check', 'Bank transfer (automatic)', 'Credit card (automatic)'
])

# Quando o usuário clicar em "Prever"
if st.button('Prever Churn'):
    df_input = pd.DataFrame([inputs])

    # Aplicar get_dummies
    df_input = pd.get_dummies(df_input)

    # Alinhar com colunas esperadas pelo modelo
    df_input = df_input.reindex(columns=colunas_modelo, fill_value=0)

    # Escalar os dados
    df_scaled = scaler.transform(df_input)

    # Prever com o modelo
    pred = log_model.predict(df_scaled)
    prob = log_model.predict_proba(df_scaled)[0][1]

    if pred[0] == 1:
        st.error(f'⚠️ Este cliente tem CHANCE DE CHURN com probabilidade de {prob:.2%}.')
    else:
        st.success(f'✅ Este cliente tem baixa probabilidade de churn ({prob:.2%}).')
